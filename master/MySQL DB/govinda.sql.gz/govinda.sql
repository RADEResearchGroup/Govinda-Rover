-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 23, 2014 at 02:28 PM
-- Server version: 5.5.37
-- PHP Version: 5.4.4-14+deb7u12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `govinda`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kamera`
--

CREATE TABLE IF NOT EXISTS `tbl_kamera` (
  `kam_sh` varchar(3) NOT NULL,
  `kam_co` varchar(3) NOT NULL,
  `kam_br` varchar(3) NOT NULL,
  `kam_sa` varchar(3) NOT NULL,
  `kam_iso` varchar(4) NOT NULL,
  `kam_exp` varchar(15) NOT NULL,
  `kam_wb` varchar(15) NOT NULL,
  `kam_eff` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kamera`
--

INSERT INTO `tbl_kamera` (`kam_sh`, `kam_co`, `kam_br`, `kam_sa`, `kam_iso`, `kam_exp`, `kam_wb`, `kam_eff`) VALUES
('100', '50', '54', '48', '800', 'auto', 'auto', 'negative');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kondisi_lingkungan`
--

CREATE TABLE IF NOT EXISTS `tbl_kondisi_lingkungan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lingkungan_suhu` varchar(5) NOT NULL,
  `lingkungan_kelembapan` varchar(5) NOT NULL,
  `lingkungan_gas` varchar(4) NOT NULL,
  `lingkungan_waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `tbl_kondisi_lingkungan`
--

INSERT INTO `tbl_kondisi_lingkungan` (`id`, `lingkungan_suhu`, `lingkungan_kelembapan`, `lingkungan_gas`, `lingkungan_waktu`) VALUES
(95, '26.00', '56.00', '0', '2014-08-23 04:12:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_konfigurasi`
--

CREATE TABLE IF NOT EXISTS `tbl_konfigurasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `konfigurasi_query` varchar(1) NOT NULL,
  `konfigurasi_pass` varchar(75) NOT NULL,
  `konfigurasi_dev` varchar(25) NOT NULL,
  `konfigurasi_pwm` varchar(3) NOT NULL,
  `konfigurasi_servoX` varchar(3) NOT NULL,
  `konfigurasi_servoY` varchar(3) NOT NULL,
  `konfigurasi_flash` varchar(1) NOT NULL,
  `konfigurasi_laser` varchar(1) NOT NULL,
  `konfigurasi_wizard` varchar(1) NOT NULL,
  `konfigurasi_lang` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_konfigurasi`
--

INSERT INTO `tbl_konfigurasi` (`id`, `konfigurasi_query`, `konfigurasi_pass`, `konfigurasi_dev`, `konfigurasi_pwm`, `konfigurasi_servoX`, `konfigurasi_servoY`, `konfigurasi_flash`, `konfigurasi_laser`, `konfigurasi_wizard`, `konfigurasi_lang`) VALUES
(1, 'q', 'GRDuino', '/dev/null', '128', '90', '90', '0', '0', '1', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(75) NOT NULL,
  `user_pass` varchar(20) NOT NULL,
  `user_namaDepan` varchar(75) NOT NULL,
  `user_namaBlk` varchar(75) NOT NULL,
  `user_role` int(11) NOT NULL,
  `user_registTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user_name`, `user_pass`, `user_namaDepan`, `user_namaBlk`, `user_role`, `user_registTimestamp`) VALUES
(1, 'rade@gr.net', 'rade1*', 'Rade', 'Stikom', 1, '2014-07-09 08:57:53'),
(2, 'user@gr.net', 'user', 'User', 'Viewer', 2, '2014-07-09 08:57:59');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
